VERSION = "4.1.0"
APPLICATION_ID = "org.flozz.nautilus-terminal"
APPLICATION_NAME = "Nautilus Terminal"
