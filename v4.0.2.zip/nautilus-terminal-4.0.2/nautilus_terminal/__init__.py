VERSION = "4.0.2"
APPLICATION_ID = "org.flozz.nautilus-terminal"
APPLICATION_NAME = "Nautilus Terminal"
