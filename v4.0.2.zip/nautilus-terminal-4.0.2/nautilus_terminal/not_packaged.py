"""
This file should only be present when Nautilus Terminal is installed from
sources (Github or PyPI).

If you are packaging this application for a Linux distribution, please remove
this file, it will disable all the `--install-*` and `--uninstall-*` options of
the `nautilus-terminal` command.
"""
