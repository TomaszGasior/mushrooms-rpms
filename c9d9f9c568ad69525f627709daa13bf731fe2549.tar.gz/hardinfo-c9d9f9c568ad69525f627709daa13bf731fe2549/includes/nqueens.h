/*
 * N-Queens Problem Solver
 * Found somewhere on the Internet; can't remember where. Possibly Wikipedia.
 */
#ifndef __NQUEENS_H__ 
#define __NQUEENS_H__

int nqueens(int y);


#endif /* __NQUEENS_H__ */


