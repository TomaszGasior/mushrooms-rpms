---
name: I have a question
about: Choose this if you have a question about Nautilus Terminal
title: ''
labels: question
assignees: ''

---

<!-- Ask your question here -->
