VERSION = "4.0.6"
APPLICATION_ID = "org.flozz.nautilus-terminal"
APPLICATION_NAME = "Nautilus Terminal"
