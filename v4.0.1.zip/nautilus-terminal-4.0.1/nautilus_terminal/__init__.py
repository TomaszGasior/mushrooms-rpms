VERSION = "4.0.1"
APPLICATION_ID = "org.flozz.nautilus-terminal"
APPLICATION_NAME = "Nautilus Terminal"
