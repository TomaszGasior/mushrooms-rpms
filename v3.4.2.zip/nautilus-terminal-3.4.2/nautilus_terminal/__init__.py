VERSION = "3.4.2"
APPLICATION_ID = "org.flozz.nautilus-terminal"
