#pragma once

#include <glib.h>

extern GMainLoop *loop;
