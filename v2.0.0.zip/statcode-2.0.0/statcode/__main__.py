import statcode.statcode

if __name__ == "__main__":
    statcode.statcode.main()
